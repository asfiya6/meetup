package com.example.penpal.onboarding;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.penpal.R;

public class OnboardingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
    }
}
